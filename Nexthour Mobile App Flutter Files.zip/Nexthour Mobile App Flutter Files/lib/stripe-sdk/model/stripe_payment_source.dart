abstract class StripePaymentSource {
  String get id;
}
