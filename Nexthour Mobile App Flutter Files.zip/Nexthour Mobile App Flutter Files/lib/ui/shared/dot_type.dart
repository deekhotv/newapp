enum DotType {
  square, circle, diamond, icon
}