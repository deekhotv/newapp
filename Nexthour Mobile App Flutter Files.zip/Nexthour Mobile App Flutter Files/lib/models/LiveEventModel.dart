/// liveEvent : [{"id":1,"title":"Rock Music","slug":"rock-music","description":"A music festival is a community event oriented towards performances of singing and instrument playing that is often presented with a theme such as musical genre (e.g., blues, folk, jazz, classical music), nationality, locality of musicians, or holiday. ... Many festivals are annual, or repeat at some other interval.","type":"readyurl","iframeurl":null,"ready_url":"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4","start_time":"2021-08-28 18:19:00","end_time":"2021-08-30 18:19:00","status":1,"thumbnail":"thumb_1629290218silhouettes-concert-crowd-front-bright-stage-lights-pool-party.jpg","poster":"poster_1629290218happy-people-dance-nightclub-party-concert.jpg","genre_id":null,"detail":null,"organized_by":"Admin","created_at":"2021-08-03T14:08:26.000000Z","updated_at":"2021-08-18T09:19:14.000000Z"},{"id":2,"title":"Fasion Event","slug":"fasion-event","description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.","type":"iframeurl","iframeurl":"https://www.learningcontainer.com/wp-content/uploads/2020/05/sample-mkv-file.mkv","ready_url":null,"start_time":"2021-08-21 18:07:00","end_time":"2021-08-21 23:12:00","status":1,"thumbnail":"thumb_1629290281young-woman-with-bright-makeup-black-hat.jpg","poster":"poster_1629290281model-walks-fashion-show-spring-summer-outfit.jpg","genre_id":null,"detail":null,"organized_by":"Admin","created_at":"2021-08-03T14:12:57.000000Z","updated_at":"2021-08-18T09:08:01.000000Z"},{"id":3,"title":"Magic Show","slug":"magic-show","description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.","type":"readyurl","iframeurl":null,"ready_url":"https://www.youtube.com/watch?v=XoGo_y7TY7M","start_time":"2021-08-26 18:09:00","end_time":"2021-08-31 18:09:00","status":1,"thumbnail":"thumb_162929035713014.jpg","poster":"poster_1629278032spot-light-top-hat-with-white-gloves-wand.jpg","genre_id":null,"detail":null,"organized_by":"Admin","created_at":"2021-08-18T05:43:52.000000Z","updated_at":"2021-08-18T09:09:17.000000Z"},{"id":4,"title":"Corporate Business Workshop.","slug":"corporate-business-workshop","description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.","type":"readyurl","iframeurl":null,"ready_url":"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4","start_time":"2021-08-26 10:00:00","end_time":"2021-08-31 18:11:00","status":1,"thumbnail":"thumb_1629290481young-team-leader-big-corporation-briefing-coworkers-pointing-graph-meeting-corporate-staff.jpg","poster":"poster_1629290481meeting-mature-office-showing-presenter.jpg","genre_id":null,"detail":null,"organized_by":"Admin","created_at":"2021-08-18T05:57:30.000000Z","updated_at":"2021-08-18T09:11:21.000000Z"},{"id":5,"title":"Award Show","slug":"award-show","description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.","type":"readyurl","iframeurl":null,"ready_url":"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4","start_time":"2021-09-01 18:12:00","end_time":"2021-09-02 18:12:00","status":1,"thumbnail":"thumb_1629290565719565_150 ppp.jpg","poster":"poster_1629290565719565_150 ppp.jpg","genre_id":null,"detail":null,"organized_by":"Admin","created_at":"2021-08-18T05:59:39.000000Z","updated_at":"2021-08-18T09:12:45.000000Z"},{"id":6,"title":"Live Event Demo","slug":"live-event-demo","description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.","type":"readyurl","iframeurl":null,"ready_url":"http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4","start_time":"2021-08-19 15:11:00","end_time":"2021-08-24 15:12:00","status":1,"thumbnail":"thumb_162927975319197591.jpg","poster":"poster_162927975342341.jpg","genre_id":null,"detail":null,"organized_by":"Admin","created_at":"2021-08-18T06:12:33.000000Z","updated_at":"2021-08-18T06:12:33.000000Z"},{"id":7,"title":"Night Party","slug":"night-party","description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.","type":"readyurl","iframeurl":null,"ready_url":"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4","start_time":"2021-08-19 18:14:00","end_time":"2021-09-15 18:14:00","status":1,"thumbnail":"thumb_1629290672energetic-dancer-dynamic-glamorous-light.jpg","poster":"poster_162929067211557.jpg","genre_id":null,"detail":null,"organized_by":"Admin","created_at":"2021-08-18T06:23:37.000000Z","updated_at":"2021-08-18T09:14:32.000000Z"}]

class LiveEventModel {
  LiveEventModel({
    this.liveEvent,
  });

  LiveEventModel.fromJson(dynamic json) {
    if (json['liveEvent'] != null) {
      liveEvent = [];
      json['liveEvent'].forEach((v) {
        liveEvent?.add(LiveEvent.fromJson(v));
      });
    }
  }
  List<LiveEvent>? liveEvent;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (liveEvent != null) {
      map['liveEvent'] = liveEvent?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// id : 1
/// title : "Rock Music"
/// slug : "rock-music"
/// description : "A music festival is a community event oriented towards performances of singing and instrument playing that is often presented with a theme such as musical genre (e.g., blues, folk, jazz, classical music), nationality, locality of musicians, or holiday. ... Many festivals are annual, or repeat at some other interval."
/// type : "readyurl"
/// iframeurl : null
/// ready_url : "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4"
/// start_time : "2021-08-28 18:19:00"
/// end_time : "2021-08-30 18:19:00"
/// status : 1
/// thumbnail : "thumb_1629290218silhouettes-concert-crowd-front-bright-stage-lights-pool-party.jpg"
/// poster : "poster_1629290218happy-people-dance-nightclub-party-concert.jpg"
/// genre_id : null
/// detail : null
/// organized_by : "Admin"
/// created_at : "2021-08-03T14:08:26.000000Z"
/// updated_at : "2021-08-18T09:19:14.000000Z"

class LiveEvent {
  LiveEvent({
    this.id,
    this.title,
    this.slug,
    this.description,
    this.type,
    this.iframeurl,
    this.readyUrl,
    this.startTime,
    this.endTime,
    this.status,
    this.thumbnail,
    this.poster,
    this.genreId,
    this.detail,
    this.organizedBy,
    this.createdAt,
    this.updatedAt,
  });

  LiveEvent.fromJson(dynamic json) {
    id = json['id'];
    title = json['title'];
    slug = json['slug'];
    description = json['description'];
    type = json['type'];
    iframeurl = json['iframeurl'];
    readyUrl = json['ready_url'];
    startTime = json['start_time'];
    endTime = json['end_time'];
    status = json['status'];
    thumbnail = json['thumbnail'];
    poster = json['poster'];
    genreId = json['genre_id'];
    detail = json['detail'];
    organizedBy = json['organized_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }
  int? id;
  String? title;
  String? slug;
  String? description;
  String? type;
  dynamic iframeurl;
  String? readyUrl;
  String? startTime;
  String? endTime;
  int? status;
  String? thumbnail;
  String? poster;
  dynamic genreId;
  dynamic detail;
  String? organizedBy;
  String? createdAt;
  String? updatedAt;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['title'] = title;
    map['slug'] = slug;
    map['description'] = description;
    map['type'] = type;
    map['iframeurl'] = iframeurl;
    map['ready_url'] = readyUrl;
    map['start_time'] = startTime;
    map['end_time'] = endTime;
    map['status'] = status;
    map['thumbnail'] = thumbnail;
    map['poster'] = poster;
    map['genre_id'] = genreId;
    map['detail'] = detail;
    map['organized_by'] = organizedBy;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    return map;
  }
}
