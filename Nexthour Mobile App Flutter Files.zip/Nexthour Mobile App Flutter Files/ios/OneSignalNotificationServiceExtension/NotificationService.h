//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created by Neeraj Chechani on 16/11/22.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
